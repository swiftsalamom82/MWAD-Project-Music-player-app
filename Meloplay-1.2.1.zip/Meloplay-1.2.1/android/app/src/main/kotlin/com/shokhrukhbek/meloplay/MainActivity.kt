package com.shokhrukhbek.meloplay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
