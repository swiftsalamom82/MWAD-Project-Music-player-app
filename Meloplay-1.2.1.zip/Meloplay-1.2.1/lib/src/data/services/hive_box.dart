class HiveBox {
  static const String boxName = 'myBox';

  static const String themeKey = 'theme';
  static const String favoriteSongsKey = 'favoriteSongs';
  static const String favoriteArtistsKey = 'favoriteArtists';
  static const String favoriteAlbumsKey = 'favoriteAlbums';
  static const String recentlyPlayedSongsKey = 'recentlyPlayedSongs';
}
